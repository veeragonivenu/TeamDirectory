import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { styled } from "@mui/material/styles";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import InputBase from "@mui/material/InputBase";
import SearchIcon from "@mui/icons-material/Search";
import Avatar from "@mui/material/Avatar";
import Paper from "@mui/material/Paper";
import AddIcon from '@mui/icons-material/Add'; 

 

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: "black",
  width: "100%",
  "& .MuiInputBase-input": {
    padding: theme.spacing(1, 1, 1, 0),
    paddingLeft: `calc(1em + ${theme.spacing(4)})`,
    transition: theme.transitions.create("width"),
  },
}));

const Item = styled(Paper)(({ theme }) => ({
  
}));

const Line = styled("hr")(({ theme }) => ({
  width: "100%",
  border: 0,
  height: 1,
  backgroundColor: theme.palette.divider,
}));

 
 

export default function SearchAppBar() {
  const [data, setData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('/data.json');
        setData(response.data);
      } catch (error) {
        console.error('Error fetching data: ', error);
      }
    };
    fetchData();
  }, []);

  useEffect(() => {
    setFilteredData(
      data.filter(item =>
        `${item.first_name} ${item.last_name} ${item.email} ${item.role}`.toLowerCase().includes(searchQuery.toLowerCase())
      )
    );
  }, [data, searchQuery]);

  const handleSearchChange = (event) => {
    setSearchQuery(event.target.value);
  };

  const admins = filteredData.filter(item => item.role === "admin");
  const members = filteredData.filter(item => item.role === "member");

  return (
    <div  className="global-styles">
      <Box sx={{ flexGrow: 1 }}>
        <AppBar position="static">
          <Toolbar>
            <Typography variant="h6" noWrap sx={{ flexGrow: 1 }}>
              Team
            </Typography>
            <div className="searchcontent">
              <div className="search-icon-wrapper">
                <SearchIcon />
              </div>
              <StyledInputBase className='searchmain'
                placeholder="Search…"
                inputProps={{ 'aria-label': 'search' }}
                value={searchQuery}
                onChange={handleSearchChange}
              />
            </div>
          </Toolbar>
        </AppBar>
        <Box>
          <Typography variant="h4" className="headingmain">
            Administrators
          </Typography>
          <Box sx={{ padding: '0 20px' }}>
            <Box display="grid" gridTemplateColumns="repeat(4, 1fr)" gap={2}>
              {admins.map(item => (
                <React.Fragment key={item.email}>
                  <Box>
                    <Item className='Miancontent'>
                      <Avatar alt={`${item.first_name} ${item.last_name}`} src={item.img} />
                      <Box sx={{ marginLeft: 2 }}>
                        <Typography className="bold-text">{`${item.first_name} ${item.last_name}`}</Typography>
                        <Typography>{item.email}</Typography>
                      </Box>
                    </Item>
                  </Box>
                </React.Fragment>
              ))}
            </Box>
          </Box>
          <Line />
          <Typography variant="h4" className="headingmain">
            Members
          </Typography>
          <Box sx={{ padding: '0 20px' }}>
            <Box display="grid" gridTemplateColumns="repeat(4, 1fr)" gap={2}>
              {members.map(item => (
                <React.Fragment key={item.email}>
                  <Box>
                    <Item className='Miancontent'>
                      <Avatar alt={`${item.first_name} ${item.last_name}`} src={item.img} />
                      <Box sx={{ marginLeft: 2 }}>
                        <Typography className="bold-text">{`${item.first_name} ${item.last_name}`}</Typography>
                        <Typography>{item.email}</Typography>
                      </Box>
                    </Item>
                  </Box>
                </React.Fragment>
              ))}
            </Box>
          </Box>
        </Box>
      </Box>
      <div className='add-icon'>
        <AddIcon color="primary" fontSize="large" />
      </div>
    </div>
  );
}
