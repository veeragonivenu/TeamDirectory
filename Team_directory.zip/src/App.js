 
import './App.css';
import Mainer from './header/header'

function App() {
  return (
    <div className="App">
     < Mainer/> 
    
    </div>
  );
}

export default App;
 